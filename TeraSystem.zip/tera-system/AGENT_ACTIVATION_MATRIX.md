﻿# AGENT_ACTIVATION_MATRIX.md

# مصفوفة تفعيل العملاء الفرعيين — Sub-Agent Activation Matrix

هذا الملف يحدد **متى يتم تفعيل كل عميل فرعي** في منظومة Tera، ومتى **لا** يتم تفعيله.

---

## القاعدة الحاكمة

> **لا يتم تفعيل العميل لأنه موجود، بل لأنه مطلوب بسبب Trigger واضح.**

Tera هو المسؤول الوحيد عن قرار التفعيل. العميل لا يُفعّل نفسه ولا يُفعّل عملاء آخرين.

---

## 1. أنواع Triggers

| نوع Trigger | وصف | مثال |
|---|---|---|
| `PHASE_GATE` | بداية مرحلة معينة | Phase 4 → Preparation, Phase 6 → Implementation |
| `DOCUMENT_READY` | وجود ملف معين جاهز | `03_MODULES_AND_FEATURES.md` معتمد → DataDesignAgent |
| `DECISION_MADE` | قرار من Tera أو المستخدم | "نحتاج تكامل API خارجي" → IntegrationAgent |
| `COMPLEXITY_SIGNAL` | مؤشر تعقيد | حجم بيانات كبير → PerformanceAgent |
| `RISK_SIGNAL` | مؤشر خطر | بيانات حساسة → SecurityAgent |
| `USER_REQUEST` | طلب مباشر من المستخدم | "أضف Domain Research" → DomainResearchAgent |
| `EXTERNAL_FACTOR` | عامل خارجي | مشروع عميل خارجي → Client Engagement Agents |
| `REVIEW_NEEDED` | حاجة مراجعة | بعد عدة مهام تنفيذية، أو ظهور مؤشرات technical debt / maintainability drift → QualityReviewCoordinatorAgent / Auditor / Monitor |
| `PHASE_7_GATE` | بداية Phase 7 | QAAndAcceptanceAgent + DocumentationHandoverAgent |

---

## 2. مصفوفة التفعيل حسب العميل

### 2.1 العملاء الأساسيون

| العميل | المعرف | Trigger التفعيل | المرحلة | متى لا يُفعّل | الحد الأدنى من المدخلات |
|---|---|---|---|---|---|
| RequirementsScopeAgent | `REQ_SCOPE_AGENT` | `DOCUMENT_READY`: بعد `TERA_PROJECT_DECISION.md` أو `00_PROJECT_INPUTS.md` | 2–3 | إذا كانت الفكرة بسيطة وواضحة بالكامل ويمكن لـ Tera كتابة `01_PROJECT_BRIEF.md` مباشرة | `00_PROJECT_INPUTS.md` أو `TERA_PROJECT_DECISION.md` |
| BusinessWorkflowAgent | `BUSINESS_WORKFLOW_AGENT` | `DOCUMENT_READY`: بعد اعتماد `01_PROJECT_BRIEF.md` + `02_SCOPE_AND_BOUNDARIES.md` + وجود workflows | 3–4 | إذا كان التطبيق لا يحتوي أي دورة عمل أو حالات (مثل CRUD بسيط بدون موافقات) | `01_PROJECT_BRIEF.md` + `02_SCOPE_AND_BOUNDARIES.md` |
| UIUXStructureAgent | `UI_UX_STRUCTURE_AGENT` | `DOCUMENT_READY`: بعد اعتماد الموديولات ومسارات العمل | 4 | إذا كان المشروع API-only أو Backend-only بدون واجهة مستخدم | `03_MODULES_AND_FEATURES.md` + `05_BUSINESS_WORKFLOWS.md` |
| UIVisualDesignerAgent | `UI_VISUAL_DESIGNER_AGENT` | `COMPLEXITY_SIGNAL`: وجود Frontend مهم أو مصدر تصميم (Figma, getdesign.md, screenshots) | 4–5 | إذا كان المشروع API-only، أو UI بسيط جدًا بدون متطلبات بصرية | `07_SCREENS_AND_UI_STRUCTURE.md` + مصدر التصميم |
| DataDesignAgent | `DATA_DESIGN_AGENT` | `DOCUMENT_READY`: بعد وضوح الموديولات والعمليات | 4 | إذا كان التطبيق لا يملك بيانات مترابطة (مثل موقع بسيط بمحتوى ثابت) | `03_MODULES_AND_FEATURES.md` + `05_BUSINESS_WORKFLOWS.md` |
| SolutionArchitectureAgent | `SOLUTION_ARCH_AGENT` | `PHASE_GATE`: قبل التنفيذ (Phase 5) | 5 | إذا كان المشروع صغيرًا جدًا والتقنيات محددة مسبقًا بدون قرارات معمارية مؤثرة | `08_TECHNICAL_ARCHITECTURE.md` أو `00_PROJECT_INPUTS.md` |
| EngineeringAgent | `ENGINEERING_AGENT` | `PHASE_GATE`: عند وجود مهمة تنفيذية مع `Pre-Execution Gate: PASS` | 6 | لا يُفعّل بدون `TASK-COD-*` معتمد. لا يُفعّل لتحضير أو تحليل | ملفات التحليل والتصميم المعتمدة + `TASK-ID` + `Pre-Execution Gate: PASS` |
| QAAndAcceptanceAgent | `QA_ACCEPTANCE_AGENT` | `PHASE_GATE`: قبل إعداد خطة التنفيذ وبعد التنفيذ وقبل Phase 7 | 5–6–7 | إذا كانت المهمة بسيطة ومعايير القبول واضحة ويمكن لـ Tera مراجعتها مباشرة | `10_TESTING_AND_ACCEPTANCE.md` أو ملفات المهمة المنفذة |
| DocumentationHandoverAgent | `DOC_HANDOVER_AGENT` | `PHASE_7_GATE`: عند قرب التسليم أو في Phase 7 | 7 | إذا كان المشروع داخليًا small ولن يُسلّم لطرف آخر | ملفات التحليل والتصميم المعتمدة |

---

### 2.2 العملاء المشروطون

| العميل | المعرف | Trigger التفعيل | المرحلة | متى لا يُفعّل | الحد الأدنى من المدخلات |
|---|---|---|---|---|---|
| SecurityAgent | `SECURITY_AGENT` | `RISK_SIGNAL`: بيانات حساسة، Auth، صلاحيات مدفوعات، أسرار، Middleware، Config حرجة | 5–6–7 | إذا لم يكن هناك أي بيانات حساسة أو صلاحيات أو تكاملات خارجية | `04_USERS_ROLES_PERMISSIONS.md` + `08_TECHNICAL_ARCHITECTURE.md` |
| IntegrationAgent | `INTEGRATION_AGENT` | `EXTERNAL_FACTOR`: API خارجي، بوابة دفع، Webhooks، ERP خارجي | 5–6 | إذا كان المشروع لا يتصل بأي خدمة خارجية | `14_INTEGRATIONS_AND_EXTERNAL_SERVICES.md` أو ما يعادلها |
| DevOpsDeploymentAgent | `DEVOPS_DEPLOYMENT_AGENT` | `EXTERNAL_FACTOR / USER_REQUEST`: نشر فعلي، CI/CD، Docker، Cloud، Domain/SSL | 6–7 | إذا كان المشروع في بيئة محلية فقط أو لا يحتاج نشر رسمي بعد | `22_DEPLOYMENT_AND_ENVIRONMENTS.md` أو `08_TECHNICAL_ARCHITECTURE.md` |
| PerformanceAgent | `PERFORMANCE_AGENT` | `COMPLEXITY_SIGNAL`: حجم بيانات كبير، مستخدمون كثر، SLA، بطء متوقع | 5–6 | إذا كان المشروع صغيرًا وعدد المستخدمين محدودًا | `06_DATA_MODEL_PREPARATION.md` + `32_PERFORMANCE_REQUIREMENTS.md` |
| ComplianceAgent | `COMPLIANCE_AGENT` | `RISK_SIGNAL`: متطلبات قانونية، بيانات شخصية، مالية، قطاع منظم | 5–6–7 | إذا لم يكن المشروع خاضعًا لأي تنظيم أو امتثال | `34_COMPLIANCE_AND_LEGAL_NOTES.md` أو `02_SCOPE_AND_BOUNDARIES.md` |
| ReportingAnalyticsAgent | `REPORTING_ANALYTICS_AGENT` | `COMPLEXITY_SIGNAL`: تقارير كثيرة، Dashboard، KPIs، تصدير | 5–6 | إذا كان التطبيق لا يحتوي تقارير أو لوحات بيانات | `13_REPORTS_AND_DASHBOARDS.md` |
| MaintenanceMigrationAgent | `MAINTENANCE_MIGRATION_AGENT` | `EXTERNAL_FACTOR`: نظام قائم، ترحيل بيانات، Legacy | 5–6–7 | إذا كان المشروع جديدًا بالكامل بدون ترحيل | `31_MAINTENANCE_AND_SUPPORT.md` أو `00_PROJECT_INPUTS.md` |
| ProjectControlAgent | `PROJECT_CONTROL_AGENT` | `REVIEW_NEEDED`: عند الحاجة لتحديث سجلات `project-control` أو فحص اتساق | 4–5–6–7 | إذا لم تكن هناك حاجة لتحديث سجلات متعددة أو فحص اتساق | ملفات project-control الحالية |
| SoftwareDesignerAgent | `SOFTWARE_DESIGNER_AGENT` | `PHASE_GATE` + `RISK_ACTIVATED`: إلزامي للمهام المؤثرة (DB, API, BL, Security, Workflow, Cross-module, Architecture, Migration, UI Structure, Financial/Inventory). Fast Path مسموح للمهام منخفضة الخطورة حسب شروط SCP-016 | 5 | **عندما تكون المهمة Low-risk** ولا تمس أي مجال حساس — يُتجاوز عبر Fast Path مع توثيق السبب | ملفات التحضير المعتمدة + سياق المهمة من Tera |
| QualityReviewCoordinatorAgent | `QUALITY_REVIEW_COORDINATOR_AGENT` | `REVIEW_NEEDED`: قبل مرحلة تنفيذ كبيرة، أو بعد عدة مهام، أو قبل Release | 5–6–7 | إذا كان المشروع صغيرًا والمهام قليلة ويمكن لـ Tera متابعتها يدويًا | `PROJECT_STATE.md` + `TASK_REGISTRY.md` |
| PlanComplianceReviewAgent | `PLAN_COMPLIANCE_REVIEW_AGENT` | `REVIEW_NEEDED`: نهاية Phase، أو بعد دفعة مهام رئيسية، أو قبل قبول MVP | 5–6–7 | إذا كان التنفيذ متوافقًا بوضوح مع الخطة ولا توجد انحرافات ظاهرة | `PROJECT_MASTER_PLAN.md` + `TASK_REGISTRY.md` |
| DomainResearchAgent | `DOMAIN_RESEARCH_AGENT` | `COMPLEXITY_SIGNAL / USER_REQUEST`: مجال غير مألوف، أو حاجة بحث خارجي | 1–2–3 | إذا كان المجال معروفًا بالكامل أو المستخدم قدم جميع المعلومات المطلوبة | Domain Research Brief من Tera |
| DomainExpertAgent | `DOMAIN_EXPERT_AGENT` | `COMPLEXITY_SIGNAL`: بعد اكتمال Domain Research، أو عند الحاجة لتحليل متقدم | 2–3–4 | إذا لم يُظهر Domain Research نتائج تستدعي تحليلًا إضافيًا | Domain Research Report + Domain Research Brief |

---

### 2.3 عملاء التعامل مع العملاء الخارجيين

> **ملاحظة نظامية:** `ClientDiscoveryAgent` و `ProposalScopeAgent` و `ClientApprovalReviewAgent` و `ChangeControlAgent` أُزيلوا من هذا الجدول. مسؤولياتهم دُمجت في `TeraClientEngagementAgent` (عميل حوكمة مستقل — راجع §2.4). راجع `tera-system/TeraClientEngagement.md`.

### 2.3.1 Checker Activation After Maker Handback (جديد — حوكمة الوثائق)

بعد أن يكمل Maker (عميل إنتاج ملفات التحضير) مهمته ويسلّم Handback إلى Tera، يُفعّل **Checker** وفق القواعد التالية:

| Trigger | Action | Checker Agent |
|---|---|---|
| `TASK-PREP-Handback` من Maker مع Lifecycle Header وحالة = `Draft` | Tera يسلّم الملف إلى Checker للمراجعة التقاطعية | كما هو محدّد في `PREPARATION_PLAN.md` (عمود Checker Agent) |
| `Checker Handback` مع PASS | Tera يراجع النتائج، يكتشف التناقضات، ويقرر ترقية الحالة إلى `Under Cross-Review` ثم إلى `MBA` أو إعادتها إلى `Draft` | — |
| `Checker Handback` مع FAIL | Tera يعيد الملف إلى Maker مع documented findings ويعيد الحالة إلى `Draft` | — |

**قواعد:**
- Checker يجب أن يكون **عميلاً مختلفاً** عن Maker (لا يمكنه مراجعة نفسه).
- لا يمكن تجاوز Checker — أي ملف تحضيري يجب أن يمر عبر Cross-Review قبل الوصول إلى `Module Baseline Approved`.
- إذا لم يُحدّد Checker في `PREPARATION_PLAN.md`، Tera هو المسؤول عن المراجعة (يعمل كـ Checker مؤقت).

### 2.4 عملاء جلسات الحوكمة الرئيسية

هؤلاء لا يخضعون للتفعيل التلقائي بواسطة Tera. المالك يفتحهم أو يطلب عملهم يدويًا حسب مجريات المشروع.

| العميل | المعرف | Trigger التشغيل | المرحلة | متى لا يعمل | الحد الأدنى من المدخلات |
|---|---|---|---|---|---|
| Auditor | `AUDITOR_AGENT` | `USER_REQUEST`: طلب تدقيق جودة/عمل أو commit بعد قبول مرحلة، أو مراجعة maintainability/engineering governance | 5–6–7 | قبل وجود تسليم موثق أو قبل قبول المالك للـ commit | `PROJECT_STATE.md` + `TASK-ID` أو ملفات التغيير |
| Monitor | `MONITOR_AGENT` | `USER_REQUEST`: طلب مراجعة توافق الخطة أو كشف الانحراف، بما في ذلك انحرافات Engineering Governance عن الخطة | 3–7 | إذا لا توجد خطة أو لا توجد مرحلة/دفعة لمقارنتها | `PROJECT_MASTER_PLAN.md` أو الخطة المتاحة + `TASK_REGISTRY.md` |
| Design Reviewer | `DESIGN_REVIEWER_AGENT` | `USER_REQUEST`: طلب تدقيق بصري أو عند وجود مهمة UI/UX | 5–7 | إذا لا يوجد UI أو لا يوجد مصدر تصميم معتمد | `28_UI_UX_GUIDELINES.md` + المهمة/الشاشة ذات العلاقة |
| **TeraClientEngagementAgent** | `CLIENT_ENGAGEMENT_AGENT` | `CLIENT_REQUEST`: بداية مشروع عميل جديد، أو طلب إدارة تغيير، أو طلب تحضير تسليم/صيانة، أو حاجة لتقدير تجاري | Client Lifecycle (كل دورة حياة الزبون) | إذا كان الطلب تقنياً بحتاً (ليس تعامل مع زبون) | `CLIENT_INTAKE.md` أو `TERA_HANDOFF_PACKAGE.md` أو طلب من Majed |

---

## 3. مصفوفة التفعيل حسب نوع المشروع

### 3.1 مشروع صغير (CRUD بسيط)

| العميل | هل يُفعّل؟ | ملاحظة |
|---|---|---|
| RequirementsScopeAgent | اختياري | إذا كانت الفكرة بسيطة وواضحة، يمكن لـ Tera كتابة `01_PROJECT_BRIEF.md` مباشرة |
| BusinessWorkflowAgent | لا | إذا لم يكن هناك workflows |
| UIUXStructureAgent | اختياري | إذا كان هناك واجهة بسيطة |
| UIVisualDesignerAgent | لا | إلا إذا قدم المستخدم ألوانًا أو مصدر تصميم |
| DataDesignAgent | اختياري | إذا كانت البيانات مترابطة |
| SolutionArchitectureAgent | لا | التقنيات محددة مسبقًا |
| EngineeringAgent | نعم | مع `Pre-Execution Gate: PASS` |
| QAAndAcceptanceAgent | اختياري | يمكن لـ Tera مراجعة المهمة مباشرة |
| DocumentationHandoverAgent | لا | |
| SecurityAgent | لا | إلا إذا كان هناك Auth |
| باقي المشروطون | لا | لا triggers كافية |

### 3.2 مشروع متوسط (تطبيق ويب متكامل مع Dashboard)

| العميل | هل يُفعّل؟ | ملاحظة |
|---|---|---|
| RequirementsScopeAgent | نعم | |
| BusinessWorkflowAgent | نعم | إذا كان هناك workflows |
| UIUXStructureAgent | نعم | |
| UIVisualDesignerAgent | اختياري | إذا كان هناك متطلبات بصرية |
| DataDesignAgent | نعم | |
| SolutionArchitectureAgent | نعم | |
| EngineeringAgent | نعم | |
| QAAndAcceptanceAgent | نعم | |
| DocumentationHandoverAgent | اختياري | إذا كان هناك تسليم لطرف آخر |
| SecurityAgent | نعم | إذا كان هناك Auth أو صلاحيات |
| PerformanceAgent | اختياري | إذا توقعنا حجم مستخدمين متوسط |
| ReportingAnalyticsAgent | اختياري | إذا كان هناك Dashboard |
| ProjectControlAgent | اختياري | عند تعدد المهمات |
| SoftwareDesignerAgent | **نعم — للمهام المؤثرة** | **إلزامي للمهام المؤثرة (DB, API, BL, Security, Workflow, Cross-module, Architecture, Migration, UI Structure, Financial/Inventory). Fast Path مسموح للمهام Low-risk** |

### 3.3 مشروع ERP (نظام تخطيط موارد مؤسسة)

| العميل | هل يُفعّل؟ | ملاحظة |
|---|---|---|
| RequirementsScopeAgent | نعم | |
| BusinessWorkflowAgent | نعم | أساسي في ERP |
| UIUXStructureAgent | نعم | |
| UIVisualDesignerAgent | نعم | إذا كان UI مهمًا |
| DataDesignAgent | نعم | أساسي |
| SolutionArchitectureAgent | نعم | |
| EngineeringAgent | نعم | مع تفعيل متكرر عبر موديولات متعددة |
| QAAndAcceptanceAgent | نعم | |
| DocumentationHandoverAgent | نعم | ERP يحتاج توثيق تسليم كامل |
| SecurityAgent | نعم | ERP يحتوي صلاحيات وبيانات حساسة |
| IntegrationAgent | نعم | تكاملات خارجية متوقعة |
| DevOpsDeploymentAgent | نعم | نشر في بيئات متعددة |
| PerformanceAgent | نعم | حجم بيانات كبير |
| ComplianceAgent | اختياري | حسب المجال |
| ReportingAnalyticsAgent | نعم | ERP يحتوي تقارير كثيرة |
| MaintenanceMigrationAgent | نعم | ERP يحتاج ترحيل بيانات |
| ProjectControlAgent | نعم | إدارة تتبع متقدمة |
| SoftwareDesignerAgent | **نعم — للمهام المؤثرة** | **إلزامي للمهام المؤثرة (DB, API, BL, Security, Workflow, Cross-module, Architecture, Migration, UI Structure, Financial/Inventory). Fast Path مسموح للمهام Low-risk** |
| QualityReviewCoordinatorAgent | نعم | بعد مجموعات مهام |
| PlanComplianceReviewAgent | نعم | قبل قبول مراحل |
| DomainResearchAgent | اختياري | لمجالات ERP غير المألوفة |
| DomainExpertAgent | اختياري | لتحليل متقدم للمجال |
| Client Engagement Agents | اختياري | إذا كان ERP لعميل خارجي |

### 3.4 مشروع SaaS (منصة خدمية)

| العميل | هل يُفعّل؟ | ملاحظة |
|---|---|---|
| RequirementsScopeAgent | نعم | |
| BusinessWorkflowAgent | نعم | |
| UIUXStructureAgent | نعم | |
| UIVisualDesignerAgent | نعم | UI مهم لـ SaaS |
| DataDesignAgent | نعم | |
| SolutionArchitectureAgent | نعم | |
| EngineeringAgent | نعم | |
| QAAndAcceptanceAgent | نعم | |
| DocumentationHandoverAgent | نعم | توثيق للمستخدمين |
| SecurityAgent | نعم | Auth/Multi-tenant أساسي |
| IntegrationAgent | اختياري | حسب التكاملات |
| DevOpsDeploymentAgent | نعم | نشر مستمر |
| PerformanceAgent | نعم | قابلية التوسع |
| ReportingAnalyticsAgent | اختياري | حسب الاحتياج |
| ProjectControlAgent | اختياري | عند تعدد المهمات |
| SoftwareDesignerAgent | **نعم — للمهام المؤثرة** | **إلزامي للمهام المؤثرة (DB, API, BL, Security, Workflow, Cross-module, Architecture, Migration, UI Structure, Financial/Inventory). Fast Path مسموح للمهام Low-risk** |

---

## 4. قواعد التفعيل الصارمة

### 4.1 لا تفعيل تلقائي للعملاء

```
تفعيل العميل يتم بقرار من Tera فقط، استنادًا إلى Trigger واضح.
لا يتم تفعيل العميل تلقائيًا لمجرد دخول مرحلة أو وجود ملف جاهز.
```

### 4.2 لا تفعيل بدون مدخلات كافية

```
لا يُفعّل عميل إذا لم تتوفر المدخلات الدنيا المطلوبة.
إذا كانت المدخلات ناقصة، إما:
  - أن يكمل Tera المدخلات بنفسه
  - أو يُفعّل عميلًا آخر لتجهيز المدخلات أولاً
  - أو يطلب من المستخدم إكمالها
```

### 4.3 لا تفعيل عميل موجود بالفعل في مهمة حاليًا

```
لا يتم تفعيل نسخة جديدة من عميل موجود حاليًا في مهمة نشطة،
إلا إذا كان العميل جاهزًا لتسلم مهمة جديدة ومستقلة.
```

### 4.4 لا تفعيل عميل لمتطلبات مستقبلية

```
لا يتم تفعيل عميل بناءً على متطلبات أو سيناريوهات قد تحدث في المستقبل.
التفعيل يكون للحاجة الحالية فقط.
```

### 4.5 عميل واحد لكل اختصاص في كل مرة

```
لا يتم تفعيل عميلين لهما نفس الاختصاص (مثل اثنين EngineeringAgent) في وقت واحد
على نفس الموديول، إلا في حالات المهام المتوازية المستقلة تمامًا.
```

---

## 5. تسجيل قرار التفعيل

عند تفعيل أي عميل فرعي، يسجل Tera في `PROJECT_ACTIVITY_LOG.md`:

```
- Agent ID
- Activation Trigger
- Task ID المستهدف
- المرحلة الحالية
- Brief reason for activation
```

### 4.6 قاعدة Task Engineering Review (مدمجة في SoftwareDesignerAgent)

```text
SoftwareDesignerAgent إلزامي للمهام المؤثرة (DB, API, BL, Security, Workflow,
Cross-module, Architecture, Migration, UI Structure, Financial/Inventory Logic).
للمهام منخفضة الخطورة (لا تمس أي مجال حساس): Fast Path مسموح
(تجاوز SoftwareDesignerAgent) مع توثيق السبب من Tera في ملف المهمة.

Task Engineering Review هو مخرج داخلي ضمن TECHNICAL_SPECIFICATION.md
يُنتجه SoftwareDesignerAgent كجزء من تصميمه التقني، وليس خطوة منفصلة.
في Fast Path: Tera يقوم بالمراجعة المباشرة بدلاً من Technical Specification.

قرارات Task Engineering Review المسموحة (للمسار العادي فقط):
  APPROVED_FOR_GATE
  REVISION_REQUIRED
  SPLIT_REQUIRED
  BLOCKED_BY_MISSING_DECISION
  WRONG_AGENT
  NEEDS_PRE_REVIEW
  REJECTED_OUT_OF_SCOPE

ملاحظة: ExecutionPreparationAgent أُزيل — استُبدل بـ SoftwareDesignerAgent.
Fast Path لا يلغي Pre-Execution Gate أو Post-Execution Review.
```

يجوز أيضاً أن يسجل Tera **Trust Level الحالي** للعميل في `SUB_AGENT_STATUS.md` إن كان الملف
مفعلاً في المشروع، لكن:

```text
Trust Level لا يفعّل العميل تلقائياً.
Trust Level لا يستبدل Trigger التفعيل.
Trust Level لا يمنح قبولاً نهائياً.
```

إذا تدخل Tera على عميل فرعي أثناء التشغيل (`Stop` / `Narrow` / `Restrict` / `Suspend` / `Reinstate`)،
فيجب توثيق ذلك في `SUB_AGENT_STATUS.md` و`PROJECT_ACTIVITY_LOG.md` عند الحاجة.

---

## 6. إلغاء التفعيل أو التعطيل المؤقت

إذا تم تفعيل عميل ثم تبين أنه غير مطلوب:

1. يتم إنهاء مهمته الحالية بحالة `Cancelled` مع سبب واضح.
2. يسجل Tera الإلغاء في `PROJECT_ACTIVITY_LOG.md`.
3. لا يُعاد تفعيله إلا عند ظهور Trigger جديد ومستقل.

---

## 7. أمثلة على تطبيق القواعد

### مثال 1: مشروع ERP جديد

```
Trigger: بداية Phase 4 (Preparation)
Tera يقرر: تفعيل RequirementsScopeAgent و BusinessWorkflowAgent و DataDesignAgent
لا يُفعّل: SolutionArchitectureAgent (لأنه Phase 5)، SecurityAgent (لا يوجد موديول حساس بعد)
```

### مثال 2: طلب تغيير من عميل

```
Trigger: طلب إضافة تكامل دفع خارجي
Tera يقرر: تفعيل IntegrationAgent
ملاحظة: إدارة تغييرات العميل الآن من اختصاص TeraClientEngagementAgent — Tera ينفذ فقط بعد استلام التغيير المعتمد
```

### مثال 3: مراجعة بعد 5 مهام تنفيذية

```
Trigger: REVIEW_NEEDED
Tera يقرر: تفعيل QualityReviewCoordinatorAgent
بعد تقريره: قد يُفعّل SecurityAgent إذا وجد findings أمنية
```

---

## 8. الملخص — قاعدة التفعيل الذهبية

> **عند الشك، لا تُفعّل.**
>
> العميل هو أداة متخصصة تُستدعى للحاجة الحالية فقط،
> وليس عضوا دائمًا في فريق المشروع.
